# I was hiking in the mountains one day.
# (hiking sounds)
# I fell in a hole
# (falling sounds)
# I can't see anything
# I hear a growl
# (growling sounds)
# I hit it with my staff!
# (fight sounds)
# (heartbeat sounds)
# (kill sounds)
# (death sounds)
# I need to get out of here.
# (walking sounds)
# http://www.soundjay.com/index.html

#NOTE: FOR WINDOWS ONLY

import msvcrt
import winsound
import threading
import random
import time

def enter():
    msvcrt.getch()

def menu():
    #print "Main Menu"
    #print "(w) New Game"
    #print "(s) Quit"
    winsound.PlaySound('menu.wav', winsound.SND_ASYNC | winsound.SND_FILENAME)
    return msvcrt.getch()

def battle():
    print
    print "HB: " + str(hb) + "/10"
    print "HP: " + str(wolf) + "/5"
    print "(w) attack"
    return msvcrt.getch()

def getinp():
    return msvcrt.getch()

def clearbuff():
    while msvcrt.kbhit():
        msvcrt.getch()

loop = 0
battleloop = 0
hb = 0
wolf = 5
up = 0

while loop == 0:
    action = menu()
    hb = 0
    wolf = 5
    up = 0
    if action == "w" or action == 'W':
        #print
        #print "I was hiking in the mountains one day."
        winsound.PlaySound('dial1.wav', winsound.SND_FILENAME)
        winsound.PlaySound('walk.wav', winsound.SND_FILENAME)
        #print "I fell in a hole."
        winsound.PlaySound('dial2.wav', winsound.SND_FILENAME)
        winsound.PlaySound('fall.wav', winsound.SND_FILENAME)
        #print "Suddenly a wild wolf attacked!"
        winsound.PlaySound('dial3.wav', winsound.SND_FILENAME)
        winsound.PlaySound('startgrowl.wav', winsound.SND_FILENAME)
        time.sleep(1)
        winsound.PlaySound('ingame.wav', winsound.SND_FILENAME)
        clearbuff()
        while up < 5:
            action = getinp()
            if action == 'w' or action == 'W':
                winsound.PlaySound('walk.wav', winsound.SND_ASYNC | winsound.SND_FILENAME)
                up += 1
            elif action == 's' or action == 'S' or action == 'a' or action == 'A' or action == 'd' or action == 'D':
                winsound.PlaySound('walk.wav', winsound.SND_ASYNC | winsound.SND_FILENAME)
        while wolf > 0 and hb < 10:
            winsound.PlaySound('wolfgrowl.wav', winsound.SND_ASYNC | winsound.SND_FILENAME)
            if battleloop == 0:
                action = battle()
                if action == "w" or action == "W":
                    winsound.PlaySound('attack.wav', winsound.SND_FILENAME)
                    #print
                    #print "You club the wolf with your staff!"
                    battleloop = random.randrange(0, 2)
                    #print "The wolf yelps in pain!"
                    wolf -= 1
                    #enter()
            elif battleloop == 1:
                winsound.PlaySound('bite.wav', winsound.SND_FILENAME)
                #print "The wolf sinks its teeth in your leg!"
                hb += 2
                #enter()
                battleloop = 0
            if hb >= 10:
                #print "The wolf sinks its teeth in your throat!"
                winsound.PlaySound('dead.wav', winsound.SND_FILENAME)
                #enter()
                #print "YOU DIED"
                #enter()
                loop = 0
                clearbuff()
            elif wolf <= 0:
                #print "You bash the wolf's brains out."
                winsound.PlaySound('enemydead.wav', winsound.SND_FILENAME)
                time.sleep(2)
                clearbuff()

    elif action == "s" or action == 'S':
        winsound.PlaySound('bye.wav', winsound.SND_FILENAME)
        break
    elif action == 'a' or action == 'A':
        winsound.PlaySound('instructions.wav', winsound.SND_FILENAME)
        msvcrt.getch()
